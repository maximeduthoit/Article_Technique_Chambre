
#############################                 ANALYSING RSOIL DATA IN SOB
#############################
#author: Nathan Crequy adapted from Karel van den Meersche
#2019/08/19


#################### 1) Setting initial parameters   ####
# Cleaning the Workspace
Sys.setenv(TZ="GMT")
rm(list=ls()) #cleans every object


#we initialize the constant parameters
pressure <-101300  #air pressure (Pa)
R <- 8.3144598 # gas constant,  	m3 Pa K-1 mol-1
chamberareas <- c(0.395, 0.355)# (m2, around 0.7 *0.5 m, area ch1, area ch2)
chambervolumes <- c(0.063894525, 0.064725313)  #Volume Chambre 1, Chambre 2

#details chamber dimensions: 
#ch1: 71*55*16.3611 (mean of 18 values)
#ch2: 71*50*18.2308 (mean of 13 values)
#details tubing lengths (go and back chamber/ analyser, meters):
#ch1: chamber to solenoid valve: 33.6 + solenoid valve to analyser: 0.8 + inside the analyser: 0.5
#ch2: chamber to solenoid valve: 47.1 + solenoid valve to analyser: 0.8 + inside the analyser: 0.5
#tubing radius: 0.2 mm => we multiply total tubing length by (pi*0.2?) to get the tubing volume

library(data.table)
library(lubridate)

#################### 2) treatment_last(): Data treatment for the last file, merging with the global resu file and vizualisation  ####

treatment_last<- function(){
  file_dat<-choose.files(caption="Select your last data file")
  fichierfinal<-fread("fichierfinal.csv")
  fichierfinal$time<-as.POSIXct(as.character(fichierfinal$time), format="%Y-%m-%d %H:%M:%S")
  fichierfinal$chamber<-as.numeric(fichierfinal$chamber)
  file.remove("fichierfinal.csv")
  newfichierfinal<-rbind(fichierfinal, soilrespi(file_dat))
  newfichierfinal<-newfichierfinal[order(newfichierfinal$time, decreasing=FALSE),]
  write.csv(newfichierfinal,file="fichierfinal.csv", row.names = F)
  vizualise()
}

#################### 3) The 'soilrespi' function processes a raw data file (.dat file extenion) and writes a data frame (.dat extension) in the working directory,  ####
#with 4 rows: time (time of the data record), coef1 (CO2 flux in micromol/m?/s), CO2i (initial CO2 air concentration at the opening of the chamber, in ppm), Rsquared (of the linear model fit to the data record),chamber (1: sun or 2: shade)

soilrespi<-function(file_dat){
  dta<-fread(file_dat, skip=4, sep="auto") # read the raw data file, we skip the first 4 lines which are descriptive
  print(file_dat)
  colnames(dta)<-c("TIMESTAMP", "RECORD", "BattV", "TRef", "Tfield(1)", "Tfield(2)", "VW(1)", "VW(2)", "PA_uS(1)", "PA_uS(2)", "Active_Chamber", "CO2", "H2O")# we rename the rows with the 2nd line of the raw data file
  #we need to convert the TIMESTAMP row into POSIXct format. The problem is that TIMESTAMP is not written in the same way depending on the raw data file, so we have to distinguish 4 different formats.  
  if (substr( dta$TIMESTAMP[1],5,5)=="-"){#format: yyyy-m-dd hh:mm:ss
    dta$TIMESTAMP<- as.POSIXct(as.character(dta$TIMESTAMP), format="%Y-%m-%d %H:%M:%S") #convert timestamp in date/hour
    
  }else if (substr( dta$TIMESTAMP[1],3,3)=="/" & substr( dta$TIMESTAMP[1],6,6)=="/"){ #format: dd/mm/yyyy hh:mm:ss
    dta$TIMESTAMP<- as.POSIXct(as.character(dta$TIMESTAMP), format="%d/%m/%Y %H:%M")#convert timestamp in date/hour
    
  }else if (substr( dta$TIMESTAMP[1],3,3)=="/" & substr( dta$TIMESTAMP[1],5,5)=="/"){ #format: dd/mm/yy hh:mm:ss
    dta$TIMESTAMP<- as.POSIXct(as.character(dta$TIMESTAMP), format="%d/%m/%Y %H:%M")#convert timestamp in date/hour
    year(dta$TIMESTAMP)<-year(dta$TIMESTAMP)+2000
    
  }else if (substr( dta$TIMESTAMP[1],5,5)=="/" & substr( dta$TIMESTAMP[1],8,8)=="/"){ #format: yyyy/mm/dd hh:mm:ss
    dta$TIMESTAMP<- as.POSIXct(as.character(dta$TIMESTAMP), format="%Y/%m/%d %H:%M:%S")#convert timestamp in date/hour
  }
  
  #A raw data file contains numerous series of measures for each chamber at different times but nothing distinguish a serie from another in the dataset. 
  #So, we want to build some blocs of lines, each bloc would contain one serie of measures. 
  #We create the vectors 'opening' and 'closing' which will contain the row index of the chambers' opening/closing
  #for example: opening=(1,335, ...) and closing=(334, 699,..) when the bloc 1 is from lines 1 to 334 and the bloc 2 from lines 335 to 699. 
  #We complete 'opening' and 'closing' by analysing each 2 consecutive rows and noticing if there is a change of chamber or a time difference of more than 3 minutes (note that during a serie of measures, we measure the CO2 concentration each second)
  opening<-c(1)#we initialize the opening vector with the first row index of dta
  opening
  closing<-c()#we create the closing vector
  closing
  i<-1
  while (i<nrow(dta)) {
    if ((dta$Active_Chamber[i]!=dta$Active_Chamber[i+1]) ||abs(difftime(dta$TIMESTAMP[i], dta$TIMESTAMP[i+1], units = "mins"))>3){
      opening<-append(opening,(i+1))
      closing<-append(closing,i)}
    i<-i+1
  }
  closing<-append(closing,nrow(dta))## we insert the index of the last row because it is not taken in the "While" loop. 
  
  ##convert temperature from Celsius to Kelvin degrees
  dta$Kelvin_Temp<-dta$TRef+273.16
  dta$Kelvin_Temp
  
  ## Returning a dataframe containing the coefficients of the linear regression for each datarecord:
  #These vectors are the future columns of the dataframe
  coef1<-c()#coef1= 'a' of the 'ax+b' line, units=umol/m2/s=FLUX
  CO2i<-c()#units=ppm, initial value of CO2 
  time<-c()
  chamber<-c()
  Rsquared<-c()
  #we proceed a linear regression on each serie of measures
  for (i in 1:length(opening)){ #length(opening)= number of series of measures
    dataselection<-dta[opening[i]:(closing[i]),]#we select a serie of measures, we skip the first 20 values because of their bad accuracy 
    #due to the air renewal in the tubings (the values fluctuate a lot during the beginning of  CO2 air concentration measurement)
    dataselection$seconds <-as.numeric(1:nrow(dataselection))#we add a second counter to build the linear regression
    ##We convert CO2 concentration in ppm into umol/m?:
    dataselection$n<-pressure*chambervolumes[dataselection$Active_Chamber[1]]/R/dataselection$Kelvin_Temp# mol_air (ideal gas law: n = pV/RT)
    dataselection$CO2.umol.m2 <- dataselection$CO2*dataselection$n / chamberareas[dataselection$Active_Chamber[1]] # ppm * mol / m2 = umol_CO2/m2
    if (nrow(dataselection)>50){ #we need to have more than 50 measures (or lines) in dataselection because we skip the first 20 lines 
      #print(dataselection)
      #print(nrow(dataselection>50))
      #print(nrow(dataselection))
      CO2linearregression <- lm(CO2.umol.m2~seconds,data=dataselection[20:nrow(dataselection)]) # we build a linear regression
      coef1<-append(coef1,summary(CO2linearregression)$coef[2,1]) #coef1= 'a' of the 'ax+b' line, units=umol/m2/s=FLUX
      CO2i<-append(CO2i,summary(CO2linearregression)$coef[1,1]*chamberareas[dataselection$Active_Chamber[1]]/mean(dataselection$n)) #summary(CO2linearregression)$coef[1,1]= 'b' of the 'ax+b' line, units=umol/m2
      #so we multiply it by 1/n and by the chamber area to obtain ppm: (umol/m?)* (m?/mol)=umol/mol=ppm
      Rsquared<-append(Rsquared,summary(CO2linearregression)$r.squared) #assess the quality of the regression
      time<-append(time,dataselection$TIMESTAMP[1]) #we take the time of the beginning of the data record for each linear regression
      chamber<-append(chamber,mean(dataselection$Active_Chamber)) #we identify the chamber (Chamber1=sun or Chamber2=shade)
    }}
  
  resu<-data.frame(time,coef1,CO2i,Rsquared,chamber) #we build the dataframe
  write.csv(resu,file=paste("resu", basename(file_dat)), row.names=F) #we write the .dat file in the working directory
  return(resu)}

#################### 4) Data vizualisation: function 'vizualise()'  ####
#install.packages("ggplot2")
library("ggplot2")
library("plyr", lib.loc="~/R/win-library/3.5")
library(lubridate)
Sys.setlocale("LC_TIME", "English")
library(tidyverse)
library(stringr)

vizualise<-function(){
  ## Loading the data
  data<-read.csv("fichierfinal.csv", header=T, sep=",")
  data$time<- as.POSIXct(as.character(data$time), format="%Y-%m-%d %H:%M:%S")
  data <- data[order(data$time, decreasing=FALSE),]
  data$month<-as.factor(paste(year(data$time),"-",month(data$time)))
  for (i in 1:nlevels(data$month)) {
    levels(data$month)[i]<-paste(month.name[as.numeric(str_sub(as.character(levels(data$month)[i]), 8,9))], as.numeric(str_sub(as.character(levels(data$month)[i]), 1,4)))
  }
  data$chamber<-as.factor(data$chamber)
  ## we verify the quality of the multiple regressions
  Rsquared<-ggplot(data, aes(x = Rsquared, color=chamber==2)) +
    stat_density(aes(group = chamber),position="identity",geom="line")+
    scale_colour_manual("",values=c("#FFC125", "#008B45"), labels=c("Chamber 1: Sun", "Chamber 2: Shade"))+
    labs(title='Rsoil R� distribution by chamber')+
    theme( panel.background = element_blank())
  ggsave("R2 distribution.png", plot=Rsquared)
  
  ## We sort the data according to R2 value
  data_sorted<-subset(data, data$Rsquared>0.85)
  
  
  ## Rsoil dec->july
  graph_sorted<-ggplot(data_sorted, aes(x=time, y=coef1))+
    aes(color=chamber==2)+
    scale_colour_manual("",values=c("#FFC125", "#008B45"), labels=c("Chamber 1: Sun", "Chamber 2: Shade"))+
    labs(y=expression(paste("Rsoil"~ "(micromol"~ "m"^-2 ~ "s"^-1,")")), x="date", title = "Rsoil dec-july R2 filtered", subtitle = "R�>0.85")+
    ylim(-0.5, 5)+
    geom_point()+
    scale_x_datetime(date_labels = "%b%Y", date_breaks = "1 month")+
    theme(axis.text.x = element_text(angle = 30, vjust = 1, hjust=1), panel.background = element_blank())
  ggsave("Rsoil dec-july R2 filtered.png", plot = graph_sorted)
  
  ## Rsoil by month a graph for each month on the same window
  data_sorted2<-subset(data_sorted, ((data_sorted$month!="November 2018")&(data_sorted$month!="December 2018")))#???we suppress november and december 2018 data
  graph_by_month_sorted<-ggplot(data_sorted2, aes(x=time, y=coef1))+
    aes(color=chamber==2)+
    scale_colour_manual("",values=c("#FFC125", "#008B45"), labels=c("Chamber 1: Sun", "Chamber 2: Shade"))+
    labs(y=expression(paste("Rsoil"~ "(�mol"~ "m"^-2 ~ "s"^-1,")")), x="Date", title = "Rsoil by month R2 filtered", subtitle = "R�>0.85")+
    geom_point()+
    ylim(-1,5)+
    facet_wrap(~month, scales = ("free_x"), nrow=2, ncol=4)+
    scale_x_datetime(date_labels = "%d")+
    theme_bw()
  ggsave("Rsoil by month R2 filtered.png", plot = graph_by_month_sorted) 
  
  ##initial CO2 air concentration
  graph_sorted<-ggplot(data_sorted, aes(x=time, y=CO2i))+
    aes(color=chamber==2)+
    scale_colour_manual("",values=c("#FFC125", "#008B45"), labels=c("Chamber 1: Sun", "Chamber 2: Shade"))+
    labs(y="CO2 concentration (ppm)", x="date", title = "Above soil CO2 air concentration", subtitle = "R�>0.85")+
    geom_point()+
    ylim(300,500)+
    scale_x_datetime(date_labels = "%b%Y", date_breaks = "1 month")
  ggsave("CO2 air concentration dec-july R2 0.85.png", plot = graph_sorted)
  
  ##Rsoil diel fluctations
  data_sorted$month<-month(data_sorted$time)
  data_sorted$hour<-hour(data_sorted$time)
  datach1<-subset(data_sorted, ((data_sorted$chamber==1)&(data_sorted$month!=12)&(data_sorted$month!=11))) #we suppress data during month 11 and 12 
  
  fun_mean<-function (x){ #calculer moyenne coef1 par heure pour chaque mois
    resu<-tapply(x$coef1, x$hour, mean)
    return(resu)}
  mean_datach1=by(datach1, datach1$month, fun_mean)
  fun_sd<-function (x){ #calculer ecart type coef1 par heure pour chaque mois
    resu<-tapply(x$coef1, x$hour, sd)
    return(resu)}
  sd_datach1=by(datach1, datach1$month, fun_sd)
  
  a<-as.data.frame(unlist(mean_datach1))
  colnames(a)<-c("mean_coef1")
  sd<-as.data.frame(unlist(sd_datach1))
  colnames(sd)<-c("sd_coef1")
  data_plot<-cbind(a,sd)
  for (x in 1:nrow(a)) {
    data_plot$month[x]<-as.numeric(strsplit(names(unlist(mean_datach1)),"[.]")[[x]][1])
    data_plot$hour[x]<-as.numeric(strsplit(names(unlist(mean_datach1)),"[.]")[[x]][2])
  }
  
  data_plot$month<-as.factor(data_plot$month)
  #data_plot$month= factor(data_plot$month,levels(data_plot$month)[c(1:7)])
  labs=c()
  for (i in 1:nlevels(data_plot$month)) {
    labs<-append(labs, as.character(paste(month.name[as.numeric(levels(data_plot$month)[i])], '2019')))
  }
  levels(data_plot$month)<-labs
  
  
  diel_fluctuations_by_month<-ggplot(data_plot, aes(x=hour, y=mean_coef1))+
    scale_color_brewer("", palette="Set1",labels=c("Chamber 1: Sun"))+
    labs(y=expression(paste("Rsoil"~ "(?mol"~ "m"^-2 ~ "s"^-1,")")), x="time (hours)", title = "Rsoil diel fluctuations per month (for Chamber 1 only: Full Sun)")+
    geom_point()+
    geom_errorbar(data=data_plot, aes(x=hour,ymin=mean_coef1-sd_coef1, ymax=mean_coef1+ sd_coef1),width = .2, position = position_dodge(width = 1)) +
    facet_wrap(~month, scales = 'free')+
    theme()
  ggsave("Rsoil diel fluctuations per month.png", plot = diel_fluctuations_by_month) 
  ##
  
  ## MAX diel Rsoil by month 
  data<-read.csv("fichierfinal.csv", header=T, sep=",")
  data$time<- as.POSIXct(as.character(data$time), format="%Y-%m-%d %H:%M:%S")
  data <- data[order(data$time, decreasing=FALSE),]
  data_sorted<-subset(data, data$Rsquared>0.85)
  data_sorted$month<-month(data_sorted$time)
  data_sorted$time<- as.POSIXct(as.character(data_sorted$time), format="%Y-%m-%d %H:%M:%S")
  data_sorted$day<-day(data_sorted$time)
  fun_max<-function (x){ #calculer max coef1 par jour pour chque mois/ moyenne coef1 par heure pour chaque mois
    resu<-tapply(x$coef1, x$day, max)
    return(resu)}
  datach1<-subset(data_sorted, ((data_sorted$chamber==1)&(data_sorted$month!=12)&(data_sorted$month!=11)))
  datach2<-subset(data_sorted, ((data_sorted$chamber==2)&(data_sorted$month!=12)&(data_sorted$month!=11)))
  max_datach1<-by(datach1, datach1$month, fun_max)
  max_datach2<-by(datach2, datach2$month, fun_max)
  
  ch1max<-as.data.frame(unlist(max_datach1))
  colnames(ch1max)<-c("coef1max")
  for (x in 1:nrow(ch1max)) {
    ch1max$month[x]<-as.numeric(strsplit(names(unlist(max_datach1)),"[.]")[[x]][1])
    ch1max$day[x]<-as.numeric(strsplit(names(unlist(max_datach1)),"[.]")[[x]][2])
  }
  ch1max$chamber<-1
  ch2max<-as.data.frame(unlist(max_datach2))
  colnames(ch2max)<-c("coef1max")
  for (x in 1:nrow(ch2max)) {
    ch2max$month[x]<-as.numeric(strsplit(names(unlist(max_datach2)),"[.]")[[x]][1])
    ch2max$day[x]<-as.numeric(strsplit(names(unlist(max_datach2)),"[.]")[[x]][2])
  }
  ch2max$chamber<-2
  CO2max<-rbind(ch1max,ch2max)
  
  CO2max$month<-as.factor(CO2max$month)
  labs=c()
  for (i in 1:nlevels(CO2max$month)) {
    labs<-append(labs, as.character(paste(month.name[i], '2019')))
  }
  levels(CO2max$month)<-labs
  
  
  maxCO2<-ggplot(CO2max, aes(x=day, y=coef1max))+
    aes(color=chamber==2)+
    scale_colour_manual("",values=c("#FFC125", "#008B45"), labels=c("Chamber 1: Sun", "Chamber 2: Shade"))+
    labs(y=expression(paste("Rsoil"~ "(?mol"~ "m"^-2 ~ "s"^-1,")")), x="date", title = "Maximum diel Rsoil by month")+
    geom_point()+
    ylim(0, 4)+
    facet_wrap(~month, scales = 'free_x')+
    theme_bw()
  ggsave("max Rsoil by month.png", plot = maxCO2)
  
}


##end of function vizualise()

#instructions: 
# - if you want to analyse (to calculate R soil flux and add it to the former data) your last data file(.dat extension), execute functions 'treatment_last()' 
treatment_last()
# 'vizualise()' to plot some graphs from the global file called "fichierfinal"
#vizualise()
# - if you want to analyse multiple data files, execute lines 127 to 137 to create a global file containing Rsoil flux
# and then function 'vizualise()'

#################### 5) Reshaping of the global file  data each 30 mins####

#we import the data from final_file.csv
library(lubridate)
library(data.table)
Sys.setenv(TZ="UTC")
final_file<-read.csv("fichierfinal.csv", header=T, sep=",")
final_file$time<- as.POSIXct(as.character(final_file$time), format="%Y-%m-%d %H:%M:%S")
final_file$time<-round_date(final_file$time,"30 mins")
final_file<-final_file[order(final_file$time, decreasing=FALSE),]

list_ch1<-by(file_new_shape$ch1_coef1,file_new_shape$final_file.time, mean)
list_ch2<-by(file_new_shape$ch2_coef1,file_new_shape$final_file.time, mean)
time<-c()
ch1_coef1<-c()
ch2_coef1<-c()
for (i in 1:length(list_ch1)) {
  ch1_coef1<-append(ch1_coef1,list_ch1[[i]][1])
  ch2_coef1<-append(ch2_coef1,list_ch2[[i]][1])
  time<-append(time, names(unlist(list_ch1))[i])
}
file_new_shape<-data.frame(time,ch1_coef1,ch2_coef1)
file_new_shape$time<-as.POSIXct(as.character(file_new_shape$time), format="%Y-%m-%d %H:%M:%S")

# Find min and max. Because the data is sorted, this will be
# the first and last element.
time.min <- file_new_shape$time[1]
time.max <- file_new_shape$time[nrow(file_new_shape)]

# generate a time sequence with 1 month intervals to fill in
# missing dates
all.dates <- seq(time.min, time.max, by="30 mins")

# Convert all dates to a data frame. Note that we're putting
# the new dates into a column called "time" just like the
# original column. This will allow us to merge the data.
all.dates.frame <- data.frame(list(time=all.dates))

# Merge the two datasets: the full dates and original data
merged.data <- merge(all.dates.frame, file_new_shape, all=T)

#Write merged.data
write.csv(merged.data, file="Rsoil_each_30mins.csv", row.names = F)





### Link with max temperature
data4Rsoil <- read.csv("C:/Users/ncreq/OneDrive/Documents/Stage Senegal Respiration sol-LAPTOP-SD0MOI74/data4Rsoil.csv", stringsAsFactors=FALSE, skip=7, sep=";")
data4Rsoil$Date<-as.POSIXct(as.character(data4Rsoil$Date), format="%d/%m/%Y %H:%M")
dtes<-c(final_file$time[1], final_file$time[nrow(final_file)])
data4Rsoil<-data4Rsoil[data4Rsoil$Date >=dtes[1]  & data4Rsoil$Date<=dtes[2],]
names(data4Rsoil)[1]<-"time"
final_file<-merge(data4Rsoil, final_file, by="time")
final_file$day<-day(final_file$time)
final_file$month<-month(final_file$time)
temp_max<-function (x){ #calculate max temperature for each month
  resu<-tapply(x$IR100_Surface_Temperature_C_S1, x$day, max)
  return(resu)}
temp_max_list<-by(final_file, final_file$month, temp_max)
temp_max_data<-as.data.frame(unlist(temp_max_list))
names(temp_max_data)[1]<-"Tmax"
for (x in 1:nrow(temp_max_data)) {
  temp_max_data$month[x]<-as.numeric(strsplit(names(unlist(temp_max_list)),"[.]")[[x]][1])
  temp_max_data$day[x]<-as.numeric(strsplit(names(unlist(temp_max_list)),"[.]")[[x]][2])
}
temp_max_data$Tmax<-as.numeric(as.character(temp_max_data$Tmax))
temp_max_data<-subset(temp_max_data, ((temp_max_data$month!=12)&(temp_max_data$month!=11)))

Temperature_by_month<-ggplot(temp_max_data, aes(x=day, y=Tmax))+
  scale_colour_manual("",values=c("#CD3333"))+
  geom_point()+
  facet_wrap(~month)+
  scale_y_continuous(breaks=c(20, 30, 40, 50,60))+
  theme_bw()

#################### 6) Execute function soilrespi on all the datasets of a path and merge them into a global file ####

mypath="C:/Users/ncreq/OneDrive/Documents/Stage Senegal Respiration sol-LAPTOP-SD0MOI74/fichiers_DAT" #select the path where your raw data files are (.dat extension) are
filenames<-list.files(path = mypath, pattern="\\.dat$", full.names = TRUE)#list of the names of the raw data files
lapply(filenames,FUN=soilrespi) #we apply 'soilrespi' on these files

#Merge the resu dataframes into a global file
mypath_resu="C:/Users/ncreq/OneDrive/Documents/Stage Senegal Respiration sol-LAPTOP-SD0MOI74/Resu_DAT"#select the path where your resu data files are
filenames_resu<-list.files(path = mypath_resu, full.names = TRUE)
data_ALL<-rbindlist(lapply(filenames_resu,fread))
doublons<-which(duplicated(data_ALL$time)) #some files obverlap
datafinal<-data_ALL[-doublons] #so we supress duplicates
write.csv(datafinal,"fichierfinal.csv",row.names = F) #and write a global file



#################### ANNEXE: Source script to plot graphs separately (but older version) ####

#CO2 flux on the period dec2018-> july 2019

graph<-ggplot(data, aes(x=time, y=coef1))+
  aes(color=chamber==2)+
  scale_colour_manual("",values=c("#FFC125", "#008B45"), labels=c("Chamber 1: Sun", "Chamber 2: Shade"))+
  labs(y=expression(paste("Rsoil"~ "(?mol"~ "m"^-2 ~ "s"^-1,")")), x="date", title = "Rsoil by month_R2 filtered")+
  ylim(-1,5)+
  geom_point()+
  scale_x_datetime(date_labels = "%b%Y", date_breaks = "1 month")
ggsave("Rsoil by month_non R2 filtered.png", plot = graph)

#vizualisation by month:
graph_by_month<-ggplot(data, aes(x=time, y=coef1))+
  aes(color=chamber==2)+
  scale_colour_manual("",values=c("#FFC125", "#008B45"), labels=c("Chamber 1: Sun", "Chamber 2: Shade"))+
  labs(y="Rsoil(umol/m?/s)", x="date", title = "Rsoil by month_non R2 filtered")+
  ylim(-1,5)+
  geom_point()+
  facet_wrap(~month,scales = ("free_x"))+
  scale_x_datetime(date_labels = "%d")+
  theme_bw()
ggsave("Rsoil by month_non R2 filtered.png", plot = graph_by_month)  


#We sort data according to R? value and plot it |||||||||||||||||||||||||||||||||||||||||||
data_sorted<-subset(data, data$Rsquared>0.85)

#global graph sorted, CO2 flux on the period dec2018-> july 2019
graph_sorted<-ggplot(data_sorted, aes(x=time, y=coef1))+
  aes(color=chamber==2)+
  scale_colour_manual("",values=c("#FFC125", "#008B45"), labels=c("Chamber 1: Sun", "Chamber 2: Shade"))+
  labs(y=expression(paste("Rsoil"~ "(?mol"~ "m"^-2 ~ "s"^-1,")")), x="date", title = "Rsoil dec-july R2 filtered", subtitle = "R?>0.85")+
  ylim(-1, 5)+
  geom_point()+
  scale_x_datetime(date_labels = "%b%Y", date_breaks = "1 month")
#+stat_smooth(color="grey", method="loess")
ggsave("Rsoil dec-july R2 filtered.png", plot = graph_sorted)

#CO2 flux, a graph for each month on the same window
graph_by_month_sorted<-ggplot(data_sorted, aes(x=time, y=coef1))+
  aes(color=chamber==2)+
  scale_colour_manual("",values=c("#FFC125", "#008B45"), labels=c("Chamber 1: Sun", "Chamber 2: Shade"))+
  labs(y=expression(paste("Rsoil"~ "(?mol"~ "m"^-2 ~ "s"^-1,")")), x="date", title = "Rsoil by month R2 filtered", subtitle = "R?>0.85")+
  geom_point()+
  ylim(-1,5)+
  facet_wrap(~month, scales = ("free_x"))+
  scale_x_datetime(date_labels = "%d")+
  theme_bw()
ggsave("Rsoil by month R2 filtered.png", plot = graph_by_month_sorted) 


##initial CO2 air concentration
graph_sorted<-ggplot(data_sorted, aes(x=time, y=CO2i))+
  aes(color=chamber==2)+
  scale_colour_manual("",values=c("#FFC125", "#008B45"), labels=c("Chamber 1: Sun", "Chamber 2: Shade"))+
  labs(y="CO2 concentration (ppm)", x="date", title = "Above soil CO2 air concentration", subtitle = "with R?>0.85")+
  geom_point()+
  ylim(300,500)+
  scale_x_datetime(date_labels = "%b%Y", date_breaks = "1 month")
#+stat_smooth(color="grey", method="loess")
ggsave("CO2 air concentration dec-july R2 0.85.png", plot = graph_sorted)



###
data<-read.csv("fichierfinal.csv", header=T, sep=",")
data$time<- as.POSIXct(as.character(data$time), format="%Y-%m-%d %H:%M:%S")

##Rsoil diel fluctuations for each month: flux=f(24hours)
data$month<-month(data$time)
data$hour<-hour(data$time)
datach1<-subset(data, data$chamber==1)

fun<-function (x){ #calculer moyenne coef1 par heure pour chaque mois
  resu<-tapply(x$coef1, x$hour, mean)
  return(resu)}
mean_datach1=by(datach1, datach1$month, fun)  


a<-as.data.frame(unlist(mean_datach1))
colnames(a)<-c("coef1")
for (x in 1:nrow(a)) {
  a$month[x]<-as.numeric(strsplit(names(unlist(mean_datach1)),"[.]")[[x]][1])
  a$hour[x]<-as.numeric(strsplit(names(unlist(mean_datach1)),"[.]")[[x]][2])
}
a$month<-as.factor(a$month)
a$month= factor(a$month,levels(a$month)[c(8,9,1:7)])
a$month<-revalue(a$month, c("11"="November 2018", "12"="December 2018", "1"="January 2019", "2"="February 2019","3"="March 2019", "4"="April 2019", "5"="May 2019", "6"="June 2019","7"= "July 2019"))

daily_pattern_by_month<-ggplot(a, aes(x=hour, y=coef1))+
  scale_color_brewer("", palette="Set1",labels=c("Chamber 1: Sun"))+
  labs(y=expression(paste("Rsoil"~ "(?mol"~ "m"^-2 ~ "s"^-1,")")), x="time (hours)", title = "Rsoil diel fluctuations per month (for Chamber 1 only: Full Sun)", subtitle = "Experimental station of Sob, Region of Niakhar")+
  geom_point()+
  ylim(0,0.7)+
  facet_wrap(~month, scales = 'free_x')+
  theme()
ggsave("Rsoil diel fluctuations per month.png", plot = daily_pattern_by_month) 


#################### Dayly maximum CO2 flux ###

data<-read.csv("fichierfinal.csv", header=T, sep=",")
data$month<-month(data$time)
data$time<- as.POSIXct(as.character(data$time), format="%Y-%m-%d %H:%M:%S")
data$day<-day(data$time)
fun_max<-function (x){ #calculer max coef1 par jour pour chque mois/ moyenne coef1 par heure pour chaque mois
  resu<-tapply(x$coef1, x$day, max)
  return(resu)}
datach1<-subset(data, data$chamber==1)
datach2<-subset(data, data$chamber==2)
max_datach1<-by(datach1, datach1$month, fun_max)
max_datach2<-by(datach2, datach2$month, fun_max)

ch1max<-as.data.frame(unlist(max_datach1))
colnames(ch1max)<-c("coef1max")
for (x in 1:nrow(ch1max)) {
  ch1max$month[x]<-as.numeric(strsplit(names(unlist(max_datach1)),"[.]")[[x]][1])
  ch1max$day[x]<-as.numeric(strsplit(names(unlist(max_datach1)),"[.]")[[x]][2])
}
ch1max$chamber<-1
ch2max<-as.data.frame(unlist(max_datach2))
colnames(ch2max)<-c("coef1max")
for (x in 1:nrow(ch1max)) {
  ch2max$month[x]<-as.numeric(strsplit(names(unlist(max_datach2)),"[.]")[[x]][1])
  ch2max$day[x]<-as.numeric(strsplit(names(unlist(max_datach2)),"[.]")[[x]][2])
}
ch2max$chamber<-2
CO2max<-rbind(ch1max,ch2max)

CO2max$month<-as.factor(CO2max$month)
CO2max$month= factor(CO2max$month,levels(CO2max$month)[c(8,9,1:7)])
CO2max$month<-revalue(CO2max$month, c("11"="November 2018", "12"="December 2018", "1"="January 2019", "2"="February 2019","3"="March 2019", "4"="April 2019", "5"="May 2019", "6"="June 2019","7"= "July 2019"))


maxCO2<-ggplot(CO2max, aes(x=day, y=coef1max))+
  aes(color=chamber==2)+
  scale_colour_manual("",values=c("#FFC125", "#008B45"), labels=c("Chamber 1: Sun", "Chamber 2: Shade"))+
  labs(y=expression(paste("Rsoil"~ "(?mol"~ "m"^-2 ~ "s"^-1,")")), x="date", title = "Maximum diel Rsoil by month")+
  geom_point()+
  ylim(0, 4)+
  facet_wrap(~month, scales = 'free_x')+
  theme_bw()
ggsave("max Rsoil by month.png", plot = maxCO2)
